<?php
class SetCustomerPrices{

   private static $instance;

   public static function getInstance (){
   
        if(null === static::$instance){
            static::$instance = new static();
        }
            return static::$instance;
    }

   public function run_actions(){
        add_action( 'woocommerce_product_options_pricing',array($this,'single_products_inputs'));
        add_action( 'woocommerce_process_product_meta',array($this,'save_single_products_inputs'));
        add_action( 'woocommerce_variation_options_pricing', array($this,'variation_products_inputs'), 10,3 );
        add_action( 'woocommerce_save_product_variation',array($this,'save_variation_products_inputs'), 10, 2 ); 
    }

   public function single_products_inputs(){
        global $wp_roles;
        $post_id = get_the_ID();
        $all_roles = $wp_roles->get_names();
        foreach($all_roles as $current_role_value => $current_role_name){
            $role = get_role($current_role_value);
            if(str_contains($current_role_value,'customer') && strcmp($current_role_value,'customer') != 0){ 
                $single_product_description = 'Enter the price for '.$current_role_name;
                $single_product_value = 'cplborfw-'.$current_role_value;
                $meta_value = get_post_meta( $post_id, $single_product_value , true );
                if(empty($meta_value)){
                    $product = wc_get_product($post_id);
                    $meta_value = $product->get_price();
                }
                
                
                $field = array(
                    'id' => $current_role_value,
                    'label' => __($current_role_name, 'woocommerce'),
                    'placeholder'=> $meta_value,
                    'type' => 'number',
                    'min'=>'0.01', 
                    'step'=>'0.01',
                    'desc_tip' => 'true',
                    'description' => __($single_product_description, 'woocommerce'),
                    'value' => $meta_value,
                    'custom_attributes' => array('step' => 0.01, 'min' => 0.00)
                );

                woocommerce_wp_text_input( $field );
            }
        }
    }


    public function save_single_products_inputs($post_id){
        global $wp_roles;
        $product = wc_get_product($post_id);
        $all_roles = $wp_roles->get_names();
        foreach($all_roles as $current_role_value => $current_role_name){
            $role = get_role($current_role_value);
            if(str_contains($current_role_value,'customer') && strcmp($current_role_value,'customer') != 0){ 
                $price = $_POST[$current_role_value];
                $meta_key = 'cplborfw-'.$current_role_value;
                $product->update_meta_data( $meta_key , $price);
                update_post_meta($post_id, $meta_key, $price);
                $product->save();
            }

        }
    }


    public function variation_products_inputs($loop,$variation_data,$variation){
        global $wp_roles;
        $post_id = get_the_ID();
        $all_roles = $wp_roles->get_names();
        foreach($all_roles as $current_role_value => $current_role_name){
            $role = get_role($current_role_value);
            if(str_contains($current_role_value,'customer') && strcmp($current_role_value,'customer') != 0){ 
                $variation_id = $current_role_value.'-'.$variation->ID;
                $variation_description = 'Enter the price for '.$current_role_name;
                $variation_value = 'cplborfw-'.$current_role_value;

                $meta_value = get_post_meta( $variation->ID, $variation_value, true );
                if(empty($meta_value)){
                    $product = wc_get_product($variation->ID);
                    $meta_value = $product->get_price();
                }

                $field = array(
                    'id' => $variation_id,
                    'label' => __($current_role_name, 'woocommerce'),
                    'placeholder'=> $meta_value,
                    'type' => 'number',
                    'min'=>'0.01', 
                    'step'=>'0.01',
                    'desc_tip' => 'true',
                    'description' => __($variation_description, 'woocommerce'),
                    'value' => $meta_value,
                    'custom_attributes' => array('step' => 0.01, 'min' => 0.00)
                );
                woocommerce_wp_text_input( $field );
            }
        }
    }   

    public function save_variation_products_inputs($post_id){    
        global $wp_roles;
        $product = wc_get_product($post_id);
        $all_roles = $wp_roles->get_names();
        foreach($all_roles as $current_role_value => $current_role_name){
            $role = get_role($current_role_value);
            if(str_contains($current_role_value,'customer') && strcmp($current_role_value,'customer') != 0){ 
                $variation_id = $current_role_value.'-'.$post_id;
                $price = $_POST[$variation_id];
                $meta_key = 'cplborfw-'.$current_role_value;
                $product->update_meta_data( $meta_key , $price);
                update_post_meta($post_id,$meta_key, $price);
                $product->save();
            }
        }
    }

}
?>