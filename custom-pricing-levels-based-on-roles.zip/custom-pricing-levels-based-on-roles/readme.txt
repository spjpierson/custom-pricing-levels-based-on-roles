=== Custom Pricing Levels Based On Roles ===
Contributors: Spencer Pierson
Tags: woocommerce, pricing, roles, custom pricing
Requires at least: 5.0
Tested up to: 5.4
Stable tag: 1.0
License: GNU General Public License

This plugin for WooCommerce allows you to create different roles, and for each product you can enter individual prices for each role. This will allow your customers to have different prices based on their specific role.

== Description ==

Introducing Custom Pricing Levels Based On Roles! This plugin for WooCommerce allows you to create different roles, and for each product you can enter individual prices for each role. This will allow your customers to have different prices based on their specific role.

Features: 

* Create different roles for your shop
* Set individual prices for each product for each role
* Give customers different prices based on their specific role
* Easy to use admin interface

== Installation ==

1. Upload the plugin to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the 'Custom Pricing Levels' tab in the WooCommerce settings to configure the plugin

== Frequently Asked Questions ==

Q: How do I set up the plugin?

A: To set up the plugin, go to the 'Pricing Level' tab in the WooCommerce settings to configure the plugin.

Q: How do I add prices for each role?

A: To add prices for each role, go to the product page in the admin and scroll down to the 'Product Data' section. Here, you can enter the prices for each role.

Q: How do I create roles?

A: To create roles, go to the 'Price Level' tab in the WooCommerce settings. Here, you can create roles.

== Screenshots ==


== Changelog ==

= 1.0 =
* Initial release