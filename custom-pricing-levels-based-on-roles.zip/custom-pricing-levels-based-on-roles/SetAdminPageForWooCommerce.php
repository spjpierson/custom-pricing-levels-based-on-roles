<?php 
class SetAdminPageForWooCommerce{
    private static $instance;

    public static function getInstance (){
    
     if(null === static::$instance){
         static::$instance = new static();
     }
         return static::$instance;
    }
 
    public function run_actions(){
        add_action( 'admin_menu', array($this,'price_level_menu_page'));
     }



    // Create the admin menu page
    public function price_level_menu_page(){
        add_submenu_page( 
                        'woocommerce', 
                        'Woocommerce Price Level', 
                        'Price Level', 
                        'manage_options', 
                        'price-level', 
                        array(
                            $this,
                            'display_page_content'
                        )
                    );
    }


    // Create the content for the admin menu page
    public function display_page_content(){
        global $wp_roles;
        $all_roles = $wp_roles->get_names();
        
        // create a nonce
        $nonce = wp_create_nonce("add_role");

        // insert our new role with the nonce
        if(isset($_POST['role_name']) && wp_verify_nonce($nonce, "add_role")) {
   
            // Get the role name
	        $new_role_name = sanitize_text_field( $_POST['role_name'] );
	        $new_role_value = 'customer_'.strtolower(preg_replace('/\s+/', '_', $new_role_name));
            $wp_roles->add_role($new_role_value, $new_role_name, array("read" => true) );
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit();
        }

    ?>
    
    <div class="wrap">
	<h2>User Roles</h2>
    <form method="post">
	<?php wp_nonce_field('new_role_nonce'); ?>
	<label for="role_name">Role Name:</label>
	<input type="text" name="role_name" id="role_name" />
	<input type="submit" name="submit" value="Submit" />
    </form>
	<table class="form-table">
		<tr>
			<th>Role Name</th>
            <th>Value</th>
			<th>Capabilities</th>
        </tr>
    <?php
        foreach($all_roles as $current_role_value => $current_role_name){
            $role = get_role($current_role_value);
            if(str_contains($current_role_value,'customer')){   
                echo '<tr>'.
			    '<td>'.esc_html($current_role_name).'</td>'.
                '<td>'.esc_html($current_role_value).'</td>'.
			    '<td>'.esc_html(json_encode($role->capabilities)).'</td>'.
                '</tr>';
            }
        }
    ?>

    </table>
    </div>
    <?php
    }


}

?>