<?php
class DisplayCustomerPrice{
    private static $instance;
    
    public static function getInstance (){
   
        if(null === static::$instance){
            static::$instance = new static();
        }
            return static::$instance;
    }

    public function run_actions(){
        add_action( 'woocommerce_get_price_html', array( $this, 'display_customer_product_price' ),10,2 );
        add_filter( 'woocommerce_add_cart_item_data', array($this,'add_cart_item_data') );
        add_filter( 'woocommerce_get_item_data', array($this,'display_role_price_in_cart'), 10, 2 );
        add_action('woocommerce_cart_calculate_fees', array($this,'apply_discount_to_order_total'), 10, 1); 
        add_action('woocommerce_mini_cart_contents', array($this,'display_cart_info'));

    }


    public function display_customer_product_price($price,$product){
        $regular_price = $regular_price = $product->get_regular_price();
        $customer_price = $regular_price;
        if(is_user_logged_in() && $product->is_type('variable') ){
            $user = wp_get_current_user();
            $get_user_roles = json_encode($user->roles);
            $role = json_decode($get_user_roles);
            if(str_contains($role[0],'customer') && strcmp($role[0],'customer') != 0){
                $regular_variations_price = array();
                $customer_variation_price = array();
                $available_variations = $product->get_children();
                for($i = 0; $i <= count($available_variations)-1; ++$i ){
                    $variation = wc_get_product($available_variations[$i]);
                    array_push($regular_variations_price , floatval($variation->get_regular_price()));
                    $meta_key = 'cplborfw-'.$role[0];
                    $role_price =  get_post_meta( $available_variations[$i], $meta_key, true);
                    array_push($customer_variation_price , floatval($role_price));
                }
                sort($regular_variations_price);
                sort($customer_variation_price);
                if(!empty($regular_variations_price)){
                    $output = sprintf( __(
                        '<div ><span class="amount">'.' REGULAR PRICE %1$s - %2$s </span></div><div style="font-weight:bolder;"> YOUR PRICE %3$s - %4$s</div>'),
                        wc_price($regular_variations_price[0]),
                        wc_price($regular_variations_price[count($available_variations)-1]),
                        wc_price($customer_variation_price[0]) , 
                        wc_price($customer_variation_price[count($customer_variation_price)-1])  );
                        return $output;
                }
            }else{
                $regular_variations_price = array();
                $available_variations = $product->get_children();

                for($i = 0; $i <= count($available_variations)-1; ++$i ){
                    $variation = wc_get_product($available_variations[$i]);
                    array_push($regular_variations_price , floatval($variation->get_regular_price()));
                }

                if(!empty($regular_variations_price)){
                    sort($regular_variations_price);

                    $output = sprintf( __(
                        '<div ><span class="amount">'.' REGULAR PRICE %1$s - %2$s </span></div>'),
                        wc_price($regular_variations_price[0]),
                        wc_price($regular_variations_price[count($available_variations)-1]));
                        return $output;
                    }
            }
        }else if($product->is_type('variable')){
            $regular_variations_price = array();
            $available_variations = $product->get_children();

            for($i = 0; $i <= count($available_variations)-1; ++$i ){
                $variation = wc_get_product($available_variations[$i]);
                array_push($regular_variations_price , floatval($variation->get_regular_price()));
            }

            sort($regular_variations_price);

            $output = sprintf( __(
                '<div ><span class="amount">'.' REGULAR PRICE %1$s - %2$s </span></div>'),
                wc_price($regular_variations_price[0]),
                wc_price($regular_variations_price[count($available_variations)-1]));
                return $output;
        }
        
        if(is_user_logged_in() && $product->is_type('simple') ){
            $user = wp_get_current_user();
            $get_user_roles = json_encode($user->roles);
            $role = json_decode($get_user_roles);
            $meta_key = 'cplborfw-'.$role[0];
            if(str_contains($role[0],'customer') && strcmp($role[0],'customer') != 0){
                $customer_price = get_post_meta( $product->get_id(), $meta_key, true);
                if(empty($customer_price)){
                    update_post_meta( $product->get_id(), $meta_key, $regular_price);
                }
            }
            if ( $regular_price != $customer_price ) {
                $customer_save = floatval($regular_price) - floatval($customer_price);
                $price = sprintf( __(
                    '<div ><span class="amount">'.' REGULAR PRICE %1$s</span></div> <div style="font-weight:bolder;"><span class="amount">' . '</span> YOUR PRICE %2$s </div> <div>YOU SAVE %3$s</div>'),
                    wc_price( $regular_price ),wc_price( $customer_price ),
                    wc_price( $customer_save ) );
                    return $price;
            }else{
                $price = '<div>Price '.wc_price($regular_price).'</div>';
                return $price;
            }

        }else if($product->is_type('simple')){
            $price = '<div>Price '.wc_price($regular_price).'</div>';
            return $price;
        }else{
            if($product->is_type('variation') && is_user_logged_in()){
                $user = wp_get_current_user();
                $get_user_roles = json_encode($user->roles);
                $role = json_decode($get_user_roles);
                $meta_key = 'cplborfw-'.$role[0];
                if(str_contains($role[0],'customer') && strcmp($role[0],'customer') != 0){
                    $customer_price = get_post_meta( $product->get_id(), $meta_key, true);
                    if(empty($customer_price)){
                        update_post_meta( $product->get_id(), $meta_key, $regular_price);
                    }
                }
 
                if ( $regular_price != $customer_price ) {
                    $customer_save = floatval($regular_price) - floatval($customer_price);
                    $price = sprintf( __('<div ><span class="amount">'.' REGULAR PRICE %1$s</span></div> <div style="font-weight:bolder;"><span class="amount">' . '</span> YOUR PRICE %2$s </div> <div>YOU SAVE %3$s</div>'),
                    wc_price( $regular_price ),
                    wc_price( $customer_price ),
                    wc_price( $customer_save ) );
                    return $price;
                }else{
                    $price = '<div>Price '.wc_price($regular_price).'</div>';
                    return $price;
                }
                
            }else{
                return $price;
            }
        }
    } 
 


    public function add_cart_item_data( $cart_item_data ) {
        if(is_user_logged_in()){
            $user = wp_get_current_user();
            $get_user_roles = json_encode($user->roles);
            $role = json_decode($get_user_roles);
            if(str_contains($role[0],'customer') && strcmp($role[0],'customer') != 0){
                $cart_item_data['role_price'] =  $role[0];
            }
        }
	    return $cart_item_data;
    }



    public function display_role_price_in_cart( $data, $cart_item ) {
	    if ( isset( $cart_item['role_price'] ) ) { 
            if(is_user_logged_in()){
                global $wp_roles;
                $all_roles = $wp_roles->get_names();
                $user = wp_get_current_user();
                $get_user_roles = json_encode($user->roles);
                $role = json_decode($get_user_roles);
                $role_name = $all_roles[$role[0]];
                $customer_price = floatval(get_post_meta( $cart_item['data']->get_id(), 'cplborfw-'.$role[0], true));
                $cart_item['role_price'] = wc_price($customer_price);
                $data[] = array(
			        'name' => $role_name.' Price' ,
			        'value' => $cart_item['role_price']
		        );
	        }
        }
	    return $data;
    }


    public function apply_discount_to_order_total() {
        global $woocommerce;
        if (is_admin() && !defined('DOING_AJAX'))
            return;
 
        if (did_action('woocommerce_before_calculate_totals') >= 2)
            return;
 

        if(is_user_logged_in()){
            global $wp_roles;
            $all_roles = $wp_roles->get_names();
            $user = wp_get_current_user();
            $get_user_roles = json_encode($user->roles);
            $role = json_decode($get_user_roles);
            $role_name = $all_roles[$role[0]];
            if(str_contains($role[0],'customer') && strcmp($role[0],'customer') != 0){
                $discount_total = 0;
                $regular_price = 0; 
                $customer_price = 0;
                foreach ( $woocommerce->cart->get_cart() as $cart_item_key => $values ) {
                    $product = wc_get_product( $values['product_id'] );
                    if($product->is_type('variable')){
                        $meta_key = 'cplborfw-'.$role[0];
                        $customer_price = floatval(get_post_meta( $values['variation_id'], $meta_key, true));
                        $variation = wc_get_product($values['variation_id']);
                        $regular_price = $variation->get_price();
                    }else{
                        $meta_key = 'cplborfw-'.$role[0];
                        $customer_price = floatval(get_post_meta($values['product_id'], $meta_key, true));
                        $regular_price = $product->get_price();
                    }
                    $item_quantity = floatval($values['quantity']);
                    $discount = $regular_price - $customer_price;
                    $discount_total += $discount * $item_quantity; 
                }
                $woocommerce->cart->add_fee( __($role_name.' Discount' , 'woocommerce'), - $discount_total );
            }
        }
    
    }

    public function display_cart_info() {
        if(is_user_logged_in()){
            global $wp_roles;
            $all_roles = $wp_roles->get_names();
            $user = wp_get_current_user();
            $get_user_roles = json_encode($user->roles);
            $role = json_decode($get_user_roles);
            $role_name = $all_roles[$role[0]];
            if(str_contains($role[0],'customer') && strcmp($role[0],'customer') != 0){
                echo "<center><p>Discount Will Be Applied At Checkout</center></p>";
            }
        }
    }

}
?>