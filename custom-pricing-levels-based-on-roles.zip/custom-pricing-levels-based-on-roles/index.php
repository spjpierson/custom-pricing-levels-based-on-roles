<?php
/*
Plugin Name: Custom Pricing Levels Based On Roles
Description: This plugin for WooCommerce allows you to create different roles, and for each product you can enter individual prices for each role. This will allow your customers to have different prices based on their specific role.
Version: 1.0
Author: Spencer Pierson
License: GNU General Public License
*/

if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    die ('You need WooCommerce for this plugin to work.');
}

include("SetAdminPageForWooCommerce.php");
include("SetCustomerPrices.php");
include("DisplayCustomerPrice.php");


if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$priceLevelAdminPage = SetAdminPageForWooCommerce::getInstance();
$customerPrice = SetCustomerPrices::getInstance();

$priceLevelAdminPage->run_actions();
$customerPrice->run_actions();

$displayCart = DisplayCustomerPrice::getInstance();
$displayCart->run_actions();